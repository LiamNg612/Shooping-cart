Name:Ng Hon Ling
SID:1155136169
The index.html is the home page.